

## Docker

- docker-compose build
- docker-compose run -d
- docker ps
- docker ps -a
- docker-compose run --rm  artisan migrate
- docker-compose exec php bash
- docker-compose exec php php artisan tinker


## ElasticSearch

- $product = Product::find(1, ['name']);
- $products = Product::search($query);
- $products = Product::all($query);
- $product = Product::first($query);
- Product::destroy(1);
- $product = Product::create([
  'id' => 1,
  'name' => 'Product',
  'price' => 10
  ]);





