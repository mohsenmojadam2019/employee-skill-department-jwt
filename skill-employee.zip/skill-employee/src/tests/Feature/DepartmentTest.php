<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Route;
use Tests\TestCase;

class DepartmentTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function test_all_department()
    {
        $response = $this->get(route('department.all'));

        $response->assertStatus(200);
    }

    public function test_create_department()
    {
        $response = $this->postJson(route('department.create'), [
            'name' => 'hasan',
            'description' => 'ali'
        ]);
        $response->assertStatus(201);
    }
    public function test_update_department()
    {
        $response = $this->json('PUT', route('department.update'), [
            'id'=>3,
            'name' => 'mohsen',
            'description' => 'mojadam'
        ]);
        $response->assertStatus(200);
    }
    public function test_delete_department()
    {
        $response = $this->json('DELETE', route('department.delete'), [
            'id'=>3
        ]);

        $response->assertStatus(200);
    }
}
