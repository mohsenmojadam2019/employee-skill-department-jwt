<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;
use Tests\TestCase;

class EmployeeTest extends TestCase
{
    public function test_all_employee()
    {
        $response = $this->get(route('employee.all'));

        $response->assertStatus(200);
    }

    public function test_create_employee()
    {
        $response = $this->postJson(route('employee.create'), [
            'name' => "mohsen",
            'address' => "tehran",
            'phone' => "09165089950",
//            'image' => "",
            'skill_id' =>  1,
            'department_id' =>  2,
        ]);
        $response->assertStatus(201);
    }

//
    public function test_update_employee()
    {
        $response = $this->json('PUT', route('employee.update'), [
            'name' => "mohsen",
            'address' => "tehran",
            'phone' => "09165089950",
//            'image' =>"" ,
            'skill_id' =>  1,
            'department_id' =>  2,
        ]);
        $response->assertStatus(200);
    }
    public function test_delete_employee()
    {
        $response = $this->json('DELETE', route('employee.delete'), [
            'id'=>3
        ]);

        $response->assertStatus(200);
    }
}
