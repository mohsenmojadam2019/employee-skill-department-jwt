<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class SkillTest extends TestCase
{
    public function test_all_skill()
    {
        $response = $this->get(route('skill.all'));

        $response->assertStatus(200);
    }

    public function test_create_skill()
    {
        $response = $this->postJson(route('skill.create'), [
            'name' => 'hasan',
            'percentages' => 20
        ]);
        $response->assertStatus(201);
    }
    public function test_update_skill()
    {
        $response = $this->json('PUT', route('skill.update'), [
            'id'=>2,
            'name' => 'mohsen',
            'percentages' => 20
        ]);
        $response->assertStatus(200);
    }
    public function test_delete_skill()
    {
        $response = $this->json('DELETE', route('skill.delete'), [
            'id'=>2
        ]);

        $response->assertStatus(200);
    }
}
