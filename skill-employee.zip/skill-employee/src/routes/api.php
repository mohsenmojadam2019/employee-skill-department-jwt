<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\SkillController;
use Illuminate\Support\Facades\Route;


Route::middleware('api')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/refresh', [AuthController::class, 'refresh']);
    Route::post('/profile', [AuthController::class, 'profile']);

    Route::prefix('/department')->group(function () {
        Route::get('all', [DepartmentController::class, 'index'])->name('department.all');
        Route::get('show/{department}', [DepartmentController::class, 'show'])->name('department.show');
        Route::post('create', [DepartmentController::class, 'create'])->name('department.create');
        Route::put('update', [DepartmentController::class, 'update'])->name('department.update');
        Route::delete('delete', [DepartmentController::class, 'destroy'])->name('department.delete');
    });

    Route::prefix('/skill')->group(function () {
        Route::get('all', [SkillController::class, 'index'])->name('skill.all');
        Route::get('show/{skill}', [SkillController::class, 'show'])->name('skill.show');
        Route::post('create', [SkillController::class, 'create'])->name('skill.create');
        Route::put('update', [SkillController::class, 'update'])->name('skill.update');
        Route::delete('delete', [SkillController::class, 'destroy'])->name('skill.delete');
    });

    Route::prefix('/employee')->group(function () {
        Route::get('all', [EmployeeController::class, 'index'])->name('employee.all');
        Route::get('show/{employee}', [EmployeeController::class, 'show'])->name('employee.show');
        Route::post('create', [EmployeeController::class, 'create'])->name('employee.create');
        Route::put('update', [EmployeeController::class, 'update'])->name('employee.update');
        Route::delete('delete', [EmployeeController::class, 'destroy'])->name('employee.delete');
    });
});


