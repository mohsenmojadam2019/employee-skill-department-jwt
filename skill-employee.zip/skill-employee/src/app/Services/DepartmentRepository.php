<?php

namespace App\Services;

use App\Models\Department;

class DepartmentRepository
{

    public function all()
    {
        return Department::all();
    }

    public function create($request)
    {
        Department::create($request);
    }

    public function show($department)
    {
        return Department::find($department);

    }

    public function update($id, $request)
    {
        Department::find($id)->update($request);
    }

    public function destroy($id)
    {
        Department::destroy($id);
    }
}
