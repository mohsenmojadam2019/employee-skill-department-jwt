<?php

namespace App\Services;

use App\Http\Requests\Employee\StoreEmployeeRequest;
use Intervention\Image\Image;

trait Upload
{

    /**
     * @param StoreEmployeeRequest $request
     * @return void
     */
    public function createUpload(StoreEmployeeRequest $request): void
    {
        $name = time() . '.' . explode('/', explode(':', substr($request->image, 0, strpos($request->image, ';')))[1])[1];

        Image::make($request->image)->save(public_path('img/public/') . $name);

        $request->merge(['image' => $name]);
    }


    /**
     * @param mixed $currentPhoto
     * @return void
     */
    public function existsFile(mixed $currentPhoto): void
    {
        $employeeImage = public_path('img/public/') . $currentPhoto;
        if (file_exists($employeeImage)) {
            @unlink($employeeImage);
        }
    }

}
