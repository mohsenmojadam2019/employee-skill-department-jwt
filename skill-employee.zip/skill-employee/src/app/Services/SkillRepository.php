<?php
namespace App\Services;

use App\Models\Skill;

class SkillRepository
{

    public function all()
    {
        return Skill::all();
    }

    public function create($request)
    {
        Skill::create($request);
    }

    public function show($skill)
    {
        return Skill::find($skill);

    }

    public function update($id, $request)
    {
        Skill::find($id)->update($request);
    }

    public function destroy($id)
    {
        Skill::destroy($id);
    }
}
