<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'address', 'phone', 'image', 'skill_id', 'department_id'];

    public function skill()
    {
        return $this->belongsTo(Skill::class, 'skill_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    public static function getImageDirectory()
    {
        return '/images/posts/';
    }

    public static function getPublicDirectory()
    {
        return public_path() . static::getImageDirectory();
    }

}
