<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class EmployeeResources extends JsonResource
{
    /**
     * Transform the resource into an array.

     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'name'=>$this->name,
            'address'=>$this->address,
            'phone'=>$this->phone,
            'image'=>$this->image,
            'skills' => SkillResources::collection($this->whenLoaded('skills')),
            'departments' => DepartmentResources::collection($this->whenLoaded('departments')),
        ];
    }
}
