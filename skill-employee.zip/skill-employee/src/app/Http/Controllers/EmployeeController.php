<?php

namespace App\Http\Controllers;

use App\Http\Requests\Employee\StoreEmployeeRequest;

use App\Http\Requests\Employee\UpdateEmployeeRequest;
use App\Models\Employee;
use App\Services\Upload;
use Symfony\Component\HttpFoundation\Response;

class EmployeeController extends Controller
{

use Upload;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Employee::with('skill', 'department')->paginate(10);;
        return response()->json($data, Response::HTTP_OK);

    }

    /**
     * Store a newly created resource in storage.
     */
    public function create(StoreEmployeeRequest $request)
    {
        if ($request->image) {

            $this->createUpload($request);

        }
        Employee::create($request->validated());

        return response()->json(['message' => 'successfully'], Response::HTTP_CREATED);

    }


    /**
     * Display the specified resource.
     */
    public function show(Employee $employee)
    {
        $data = Employee::find($employee);

        return response()->json($data, Response::HTTP_OK);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateEmployeeRequest $request, Employee $employee)
    {

        $currentPhoto = $employee->image;
        if ($request->image != $currentPhoto) {
            $this->createUpload($request);
        }
        $this->existsFile($currentPhoto);
        $employee->update($request->validated());

        return response()->json(['message' => 'successfully'], Response::HTTP_OK);


    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Employee $employee)
    {
        $employee->delete();
        $currentPhoto = $employee->image;
        $this->existsFile($currentPhoto);

        return response()->json(['message' => 'successfully'], Response::HTTP_OK);
    }




}




