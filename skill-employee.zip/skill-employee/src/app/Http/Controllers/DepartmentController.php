<?php

namespace App\Http\Controllers;

use App\Http\Requests\Department\StoreDepartmentRequest;
use App\Http\Requests\Department\UpdateDepartmentRequest;
use App\Services\DepartmentRepository;

use App\Models\Department;
use App\Models\Skill;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Symfony\Component\HttpFoundation\Response;

class DepartmentController extends Controller
{

    protected $department;

    public function __construct()
    {
        $this->department = resolve(DepartmentRepository::class);
    }


    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = $this->department->all();
        return response()->json($data, Response::HTTP_OK);
    }


    /**
     * Store a newly created resource in storage.
     */
    public function create(StoreDepartmentRequest $request)
    {

        $this->department->create($request->validated());
        return response()->json(['message' => 'created successfully'], Response::HTTP_CREATED);
    }


    /**
     * Display the specified resource.
     */
    public function show(Department $department)
    {
        $data = $this->department->show($department);
        return response()->json($data, Response::HTTP_OK);
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDepartmentRequest $request)
    {
        $this->department->update($request->id, $request->validated());
        return response()->json(['message' => 'created successfully'], Response::HTTP_OK);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        $request->validate([
            'id' => ['required']
        ]);
        $this->department->destroy($request->id);
        return response()->json(['message' => 'successfully'], Response::HTTP_OK);
    }
}
