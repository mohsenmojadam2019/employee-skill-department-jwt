<?php

namespace App\Http\Controllers;

use App\Http\Requests\Skill\StoreSkillRequest;
use App\Http\Requests\Skill\UpdateSkillRequest;

use App\Models\Skill;
use App\Services\SkillRepository;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SkillController extends Controller
{
    protected $skill;

    public function __construct()
    {
        $this->skill = resolve(SkillRepository::class);
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = $this->skill->all();
        return response()->json($data, Response::HTTP_OK);
    }


    /**
     * Store a newly created resource in storage.
     */
    public function create(StoreSkillRequest $request)
    {

        $this->skill->create($request->validated());
        return response()->json(['message' => 'created successfully'], Response::HTTP_CREATED);
    }


    /**
     * Display the specified resource.
     */
    public function show(Skill $skill)
    {
        $data = $this->skill->show($skill);
        return response()->json($data, Response::HTTP_OK);
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateSkillRequest $request)
    {
        $this->skill->update($request->id, $request->validated());
        return response()->json(['message' => 'created successfully'], Response::HTTP_OK);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Skill $skill, Request $request)
    {
        $request->validate([
            'id' => ['required']
        ]);
        $this->skill->destroy($request->id);
        return response()->json(['message' => 'successfully'], Response::HTTP_OK);
    }
}
